from brain_games.games.game import brain_progression


def main():
    brain_progression()


if __name__ == '__main__':
    main()
