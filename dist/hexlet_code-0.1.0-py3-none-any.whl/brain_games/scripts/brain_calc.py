from brain_games.games.game import brain_calc


def main():
    brain_calc()


if __name__ == '__main__':
    brain_calc()
