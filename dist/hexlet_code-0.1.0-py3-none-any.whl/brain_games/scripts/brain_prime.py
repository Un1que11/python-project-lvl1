from brain_games.games.game import brain_prime


def main():
    brain_prime()


if __name__ == '__main__':
    main()
